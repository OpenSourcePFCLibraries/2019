﻿INSERT INTO examples_categories_list VALUES (
	0,
	'PFC Examples',
	0,
	0,
	1,
	1,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	1,
	'Application Services',
	0,
	0,
	3,
	4,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	3,
	'Error Services Example',
	1,
	3,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	4,
	'Split Bar 3 Pane Style',
	44,
	4,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	5,
	'File Services Example',
	1,
	20,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	6,
	'DataWindow Services',
	0,
	0,
	3,
	4,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	7,
	'Linkage Services',
	0,
	0,
	3,
	4,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	8,
	'Save Process: All DW Scenarios',
	34,
	1,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	9,
	'Basic Retrieval Arguments',
	7,
	9,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	10,
	'Basic Scrolling',
	7,
	10,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	11,
	'Basic Filters',
	7,
	11,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	12,
	'Filter Service Dialogs',
	6,
	12,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	13,
	'Sort Service Dialogs',
	6,
	13,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	14,
	'Multiple Table Update',
	6,
	14,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	15,
	'Print Preview Service',
	6,
	15,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	17,
	'Row Manager Service',
	6,
	17,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	18,
	'Row Selection Service',
	6,
	18,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	19,
	'Required Column Service',
	6,
	19,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	21,
	'Drop-down Search Services',
	999,
	0,
	3,
	4,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	22,
	'Type Ahead in the DDLB & DDPLB',
	44,
	5,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	23,
	'Drop-down Search Service',
	6,
	6,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	25,
	'Find and Replace Service',
	6,
	7,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	26,
	'Find and Replace in a RTE',
	44,
	8,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	34,
	'Window Services',
	0,
	0,
	3,
	4,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	35,
	'Window Resize Service',
	34,
	26,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	36,
	'Status Bar',
	34,
	27,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	37,
	'Across Tab Pages',
	7,
	28,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	38,
	'Split Bar Explorer Style ',
	44,
	29,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	39,
	'Resize Dynamic Tab Pages',
	34,
	30,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	40,
	'Tab Control Object',
	999,
	0,
	3,
	4,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	41,
	'Filter Service Settings',
	6,
	31,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	42,
	'Refresh Drop-down DataWindows',
	6,
	32,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	43,
	'Dynamic Filter Expressions',
	6,
	33,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	44,
	'Objects',
	0,
	0,
	3,
	4,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	46,
	'Using Rich Text Edits with Files',
	999,
	35,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	47,
	'Using Rich Text Edits with Your Database',
	999,
	36,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	48,
	'Progress Bar Sampler',
	44,
	37,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	49,
	'Retrieval with Auto-updates',
	7,
	38,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	50,
	'Filter with Cascading Keys',
	7,
	39,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	52,
	'Filter with Cascading Deletes',
	7,
	41,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	53,
	'Split Bar Object',
	999,
	0,
	3,
	4,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	55,
	'Split Bars within a Window Object',
	999,
	43,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	56,
	'Progress Bar Object',
	999,
	0,
	3,
	4,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	57,
	'Resize Freeform DataWindow',
	6,
	44,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	58,
	'Resize Grid DataWindow',
	6,
	45,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	59,
	'DDDW Calculator and Calendar',
	6,
	46,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	60,
	'Weighted Resize of a Window',
	34,
	47,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	16,
	'(5.x) Basic Listview',
	27,
	16,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	65,
	'Basic Listview',
	27,
	53,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	27,
	'TreeView and Listview',
	0,
	0,
	3,
	4,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	28,
	'(5.x) Basic Tree View',
	999,
	21,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	29,
	'(5.x) Treeview and a Listview',
	27,
	22,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	31,
	'(5.x) Update a Treeview',
	27,
	23,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	32,
	'Recursive Tree View',
	999,
	24,
	5,
	6,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	30,
	'Save Process',
	999,
	0,
	3,
	4,
	0,
	0);
INSERT INTO examples_categories_list VALUES (
	33,
	'A Logical Unit of Work',
	999,
	48,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	2,
	'Metaclass Example',
	999,
	2,
	5,
	4,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	61,
	'Basic Treeview',
	27,
	49,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	62,
	'Treeview Linked to a Listview',
	27,
	50,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	63,
	'Update a Treeview',
	27,
	51,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	64,
	'Recursive Tree View',
	999,
	52,
	5,
	6,
	1,
	0);
INSERT INTO examples_categories_list VALUES (
	20,
	'PFC 5.0 Treeview and Listview',
	999,
	0,
	3,
	4,
	0,
	0);